package lk.ijse.controller.dashboard;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.tm.customerTm;
import lk.ijse.model.CustomerModel;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class DeliveryFormController implements Initializable {

    public TextField txtCustomerID;
    public TextField txtorderID;
    public TextField txtdeliveryCost;

    public TextField txtdeliverydate;
    public TextField txtdeliveryID;
    public TextField txtdeliverydescription;
    public TableView tableDelivery;
    public TableColumn clmdeliveryId;
    public TableColumn clmdeliverydate;
    public TableColumn clmdeliveryDescription;
    public TableColumn clmdeeliverycost;
    public TableColumn clmorderID;
    public TableColumn txtcustomerId;
    public TableColumn clmCustomerId;

    public void clmdeliveryId(TableColumn.CellEditEvent cellEditEvent) {

    }

    public void clmdeliverydate(TableColumn.CellEditEvent cellEditEvent) {
    }

    public void clmdeeliverycost(TableColumn.CellEditEvent cellEditEvent) {
    }

    public void clmorderID(TableColumn.CellEditEvent cellEditEvent) {
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        clmdeliveryId.setCellValueFactory(new PropertyValueFactory<>("ID"));
        clmdeliverydate.setCellValueFactory(new PropertyValueFactory<>("Date"));
        clmdeeliverycost.setCellValueFactory(new PropertyValueFactory<>("Cost"));
        clmCustomerId.setCellValueFactory(new PropertyValueFactory<>("Contact"));

        tableListener();
        try {

            getAllDelivery();


        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private void getAllDelivery() throws SQLException, ClassNotFoundException {

        List<customerDto> customers = CustomerModel.getCustomers();
        List<customerTm> tmList = new ArrayList<>();
        for(customerDto dto: customers){
            tmList.add(new customerTm(
                    dto.getCustomerID(),
                    dto.getCustomerName(),
                    dto.getCustomerAddress(),
                    dto.getCustomerContactNumber()
            ));
        }
       // updateCustomerTable(tmList);
    }


    public void tableListener() {
    }

    public void buttonOnActionClear(ActionEvent actionEvent) {
    }
}
