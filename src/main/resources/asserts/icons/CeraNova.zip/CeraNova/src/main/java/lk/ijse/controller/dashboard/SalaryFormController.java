package lk.ijse.controller.dashboard;

public class SalaryFormController {
}
