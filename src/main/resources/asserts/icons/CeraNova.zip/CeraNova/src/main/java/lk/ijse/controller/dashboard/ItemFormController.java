package lk.ijse.controller.dashboard;

import javafx.scene.control.SortEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class ItemFormController {
    public TextField txtItemID;
    public TextField txtSize;
    public TextField txtQuantityofitem;
    public TextField txtItemtype;
    public TableColumn colItemType;
    public TableColumn colItemID;
    public TableColumn colItemsize;
    public TableColumn colQuantityofitem;
    public TextField txtsalaryId;
    public TextField txtamount;
    public TextField txtdateofissue;
    public TableView tableSalary;
    public TableColumn colsalaryId;
    public TableColumn coldateofissue;
    public TableColumn colamount;
    public TableColumn colemployeeId;

    public void tableItem(SortEvent<TableView> tableViewSortEvent) {
    }
}
