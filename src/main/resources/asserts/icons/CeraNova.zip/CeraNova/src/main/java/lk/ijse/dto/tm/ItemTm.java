package lk.ijse.dto.tm;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode

public class ItemTm {
    private String itemID;
    private String itemType;
    private String itemSize;
    private String quantityOfItem;
}
