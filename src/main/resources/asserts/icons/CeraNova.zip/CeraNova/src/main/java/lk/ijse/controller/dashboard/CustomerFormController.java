package lk.ijse.controller.dashboard;

import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import lk.ijse.db.dbconnection;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.tm.customerTm;
import javafx.scene.control.Alert;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.scene.control.cell.PropertyValueFactory;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.SortEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import lk.ijse.model.CustomerModel;

public class CustomerFormController implements Initializable {
    public TableColumn colID;
    public TableColumn colName;
    public TableColumn colContact;
    public TableColumn colAddress;
    public TextField txtCustomername;
    public TextField txtCustomerid;
    public TextField txtCustomercontactnumber;

    public TableView<customerTm> tableCustomer;

    public AnchorPane root;

    public TextField txtCustomeraddress;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        colID.setCellValueFactory(new PropertyValueFactory<>("ID"));
        colName.setCellValueFactory(new PropertyValueFactory<>("Name"));
        colAddress.setCellValueFactory(new PropertyValueFactory<>("Address"));
        colContact.setCellValueFactory(new PropertyValueFactory<>("Contact"));

        tableListener();
        try {

            getAllCustomers();


        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public void buttonOnActionClear(ActionEvent actionEvent) {

    }

    public void buttonOnActionSave(ActionEvent actionEvent) {
        String id = txtCustomerid.getText();
        String name = txtCustomername.getText();
        String address = txtCustomeraddress.getText();
        String contact = txtCustomercontactnumber.getText();
        if (id.isEmpty() || name.isEmpty() || address.isEmpty() || contact.isEmpty()){
            new Alert(Alert.AlertType.ERROR,"Field Not found").showAndWait();
            return;
        }
        customerDto dto = new customerDto(
                id,
                name,
                address,
                contact
        );
        try {
            boolean isSaved = customerDto.saveCustomer(dto);
            if (isSaved){
                new Alert(Alert.AlertType.INFORMATION,"Success").showAndWait();
                getAllCustomers();
            }else {
                new Alert(Alert.AlertType.ERROR,"Fail").showAndWait();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    ObservableList<customerTm> observableList;
    private void getAllCustomers() throws SQLException, ClassNotFoundException {
        observableList = FXCollections.observableArrayList();
        List<customerDto> customers = CustomerModel.getCustomers();

        for(customerDto dto: customers){
            observableList.add(new customerTm(
                    dto.getCustomerID(),
                    dto.getCustomerName(),
                    dto.getCustomerAddress(),
                    dto.getCustomerContactNumber()
            ));
        }
        tableCustomer.setItems(observableList);
    }



    public void buttonOnActionUpdate(ActionEvent actionEvent) {
//        tableCustomer.setItems(FXCollections.observableArrayList(list));
//        tableCustomer.refresh();
    }

    private void tableListener(){
//        tableCustomer.getSelectionModel()
//                .selectedItemProperty()
//                .addListener((observableValue, customerTm, t1) -> {
//                    txtId.setText(t1.getID());
//                    txtName.setText(t1.getName());
//                    txtAddress.setText(t1.getAddress());
//                    txtContact.setText(t1.getContact());
//                });
    }



    public void buttonOnActionDelete(ActionEvent actionEvent) {
    }

 //   private void updateCustomerTable(List<customerTm> list){
//        tableCustomer.setItems(FXCollections.observableArrayList(list));
//        tableCustomer.refresh();
  //  }
    public void buttonOnActionMakeOrder(ActionEvent actionEvent) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/order_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Order Management");
        stage.show();
    }
    public void buttonOnActionBack(ActionEvent actionEvent) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        //stage.setTitle("");
        stage.show();
    }
}
