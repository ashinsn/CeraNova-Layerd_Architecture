package lk.ijse.model;

import lk.ijse.db.dbconnection;
import lk.ijse.db.dbconnection;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.orderDto;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
/*import lk.ijse.db.dbconnection;
import lk.ijse.dto.customerDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;*/

public class OrderModel {
    public static List<orderDto> getOrder() throws SQLException, ClassNotFoundException {
        List<orderDto> list = new ArrayList<>();
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM order");
        ResultSet result = pstm.executeQuery();
        while (result.next()) {
            list.add(new orderDto(
                    result.getString("ID"),
                    result.getString("Date"),
                    result.getString("Description"),
                    result.getString("deliveryID")

            ));
        }
        return list;
    }

    public static boolean saveOrder(orderDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("INSERT INTO order (id,date,descroption) VALUES (?,?,?,?)");
        pstm.setString(1, dto.getOrderID());
        pstm.setString(2, dto.getOrderDate());
        pstm.setString(3, dto.getOrderDescription());

        return pstm.executeUpdate() > 0;
    }

    public static boolean updateCustomer(customerDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("UPDATE customer SET name=?, address=?, tel=? WHERE id = ?");
        pstm.setString(1, dto.getCustomerID());
        pstm.setString(2, dto.getCustomerName());
        pstm.setString(3, dto.getCustomerContactNumber());
        pstm.setString(4, dto.getCustomerAddress());
        return pstm.executeUpdate() > 0;
    }

    public static boolean deleteCustomer(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("DELETE customer SET name=?, address=?, tel=? WHERE id = ?");
        pstm.setString(1, id);
        return pstm.executeUpdate() > 0;
    }

    public static customerDto getCustomer(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM customer WHERE id = ?");
        pstm.setString(1, id);
        ResultSet rs = pstm.executeQuery();
        if (rs.next()) {
            return new customerDto(
                    rs.getString("ID"),
                    rs.getString("Name"),
                    rs.getString("Address"),
                    rs.getString("Contact")
            );
        }
        return null;
    }

    public static List<orderDto> getOrders() {

        //data insert

        return null;
    }

    public void getAllCustomer() throws SQLException, ClassNotFoundException {

    }
    public static String generateNextOrderId() throws SQLException, SQLException, ClassNotFoundException {
        Connection connection = dbconnection.getInstance().getConnection();

        String sql = "SELECT order_id FROM orders ORDER BY order_id DESC LIMIT 1";
        PreparedStatement pstm = connection.prepareStatement(sql);

        ResultSet resultSet = pstm.executeQuery();
        if(resultSet.next()) {
            return splitOrderId(resultSet.getString(1));
        }
        return splitOrderId(null);
    }

    private static String splitOrderId(String currentOrderId) {
        if(currentOrderId != null) {
            String[] split = currentOrderId.split("O0");

            int id = Integer.parseInt(split[1]); //01
            id++;
            return "O00" + id;
        } else {
            return "O001";
        }
    }

    public static boolean saveOrder(String orderId, String customerId, LocalDate date) throws SQLException, ClassNotFoundException {
        Connection connection = dbconnection.getInstance().getConnection();

        String sql = "INSERT INTO orders VALUES(?, ?, ?)";
        PreparedStatement pstm = connection.prepareStatement(sql);
        pstm.setString(1, orderId);
        pstm.setString(2, customerId);
        pstm.setDate(3, Date.valueOf(date));

        return pstm.executeUpdate() > 0;
    }

}
