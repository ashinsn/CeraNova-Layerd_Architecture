package lk.ijse.dto;
import javafx.scene.control.Alert;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode

public class supplierDto {
    private String supplierID;
    private String supplierName;
    private String supplierAddress;
    private String supplierContactNumber;

    public static boolean saveSupplier(supplierDto dto) {
        String id = dto.getSupplierID();
        String name = dto.getSupplierName();
        String address = dto.getSupplierAddress();
        String contact = dto.getSupplierContactNumber();
        if (id.isEmpty() || name.isEmpty() || address.isEmpty() || contact.isEmpty()){
            new Alert(Alert.AlertType.ERROR,"Field Not found").showAndWait();
            return false;
        }
        return true;
    }
}
