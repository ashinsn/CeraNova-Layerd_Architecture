package lk.ijse.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class DashboardFormController implements Initializable {
    public AnchorPane controllAra;
    @FXML
    private AnchorPane root;
   public void buttonOnActionCustomer(ActionEvent actionEvent) throws IOException {
        /*AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/customer_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Customer Manage");
        stage.show();*/

       controllAra.setVisible(true);
       FXMLLoader loader= new FXMLLoader(getClass().getResource("/view/dashboard/customer_form.fxml"));
       AnchorPane anchorPane = loader.load();
       controllAra.getChildren().removeAll();
       controllAra.getChildren().setAll(anchorPane);

    }

    public void buttonOnActionDelivery(ActionEvent actionEvent) throws IOException {
        /*AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/delivery_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Delivery Manage");
        stage.show();*/

        controllAra.setVisible(true);
        FXMLLoader loader= new FXMLLoader(getClass().getResource("/view/dashboard/delivery_form.fxml"));
        AnchorPane anchorPane = loader.load();
        controllAra.getChildren().removeAll();
        controllAra.getChildren().setAll(anchorPane);
    }

    public void buttonOnActionOrder(ActionEvent actionEvent) throws IOException{
        /*AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/order_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Order Manage");
        stage.show();*/

        controllAra.setVisible(true);
        FXMLLoader loader= new FXMLLoader(getClass().getResource("/view/dashboard/order_form.fxml"));
        AnchorPane anchorPane = loader.load();
        controllAra.getChildren().removeAll();
        controllAra.getChildren().setAll(anchorPane);

    }

    public void buttonOnActionSupplier(ActionEvent actionEvent) throws IOException {
        /*AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/supplier_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Supplier Manage");
        stage.show();*/

        controllAra.setVisible(true);
        FXMLLoader loader= new FXMLLoader(getClass().getResource("/view/dashboard/order_form.fxml"));
        AnchorPane anchorPane = loader.load();
        controllAra.getChildren().removeAll();
        controllAra.getChildren().setAll(anchorPane);

    }

    public void buttonOnActionEmployee(ActionEvent actionEvent) throws IOException {
        /*AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/employee_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Employee Manage");
        stage.show();*/

        controllAra.setVisible(true);
        FXMLLoader loader= new FXMLLoader(getClass().getResource("/view/dashboard/employee_form.fxml"));
        AnchorPane anchorPane = loader.load();
        controllAra.getChildren().removeAll();
        controllAra.getChildren().setAll(anchorPane);

    }

    public void buttonOnActionMaterial(ActionEvent actionEvent) throws IOException{
        /*AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/material_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Material Manage");
        stage.show();*/

        controllAra.setVisible(true);
        FXMLLoader loader= new FXMLLoader(getClass().getResource("/view/dashboard/material_form.fxml"));
        AnchorPane anchorPane = loader.load();
        controllAra.getChildren().removeAll();
        controllAra.getChildren().setAll(anchorPane);

    }

    public void buttonOnActionItem(ActionEvent actionEvent) throws IOException{
        /*AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/item_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Item Manage");
        stage.show();*/

        controllAra.setVisible(true);
        FXMLLoader loader= new FXMLLoader(getClass().getResource("/view/dashboard/item_form.fxml"));
        AnchorPane anchorPane = loader.load();
        controllAra.getChildren().removeAll();
        controllAra.getChildren().setAll(anchorPane);
    }

    public void buttonOnActionSalary(ActionEvent actionEvent) throws IOException {
        /*AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/salary_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Salary Manage");
        stage.show();*/

        controllAra.setVisible(true);
        FXMLLoader loader= new FXMLLoader(getClass().getResource("/view/dashboard/salary_form.fxml"));
        AnchorPane anchorPane = loader.load();
        controllAra.getChildren().removeAll();
        controllAra.getChildren().setAll(anchorPane);
    }

    public void buttonOnActionPayment(ActionEvent actionEvent) throws IOException{
        /*AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/payment_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Payment Manage");
        stage.show();*/

        controllAra.setVisible(true);
        FXMLLoader loader= new FXMLLoader(getClass().getResource("/view/dashboard/payment_form.fxml"));
        AnchorPane anchorPane = loader.load();
        controllAra.getChildren().removeAll();
        controllAra.getChildren().setAll(anchorPane);
    }

    public void buttonOnActionCustomerOrder(ActionEvent actionEvent) {

    }

    public void buttonOnActionOrderItem(ActionEvent actionEvent) {

    }

    public void buttonOnActionSupplierMaterial(ActionEvent actionEvent) {

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        controllAra.setVisible(false);
    }
}
