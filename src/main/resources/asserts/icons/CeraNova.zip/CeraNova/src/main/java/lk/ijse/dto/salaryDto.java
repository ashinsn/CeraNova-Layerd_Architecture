package lk.ijse.dto;

import lombok.*;

@Data
@ToString
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode

public class salaryDto {
    private String salaryID;
    private String dateOfIssue;
    private String amount;
}
