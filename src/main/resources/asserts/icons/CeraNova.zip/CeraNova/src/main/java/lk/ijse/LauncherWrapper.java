package lk.ijse;

public class LauncherWrapper {


    public static void main(String[] args) {
        Launcher.main(args);
    }
}
