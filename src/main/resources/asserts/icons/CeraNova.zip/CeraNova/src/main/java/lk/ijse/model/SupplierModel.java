package lk.ijse.model;

import lk.ijse.db.dbconnection;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.supplierDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SupplierModel {
    public static List<supplierDto> getSuppliers() throws SQLException, ClassNotFoundException {
        List<supplierDto> list = new ArrayList<>();
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM supplier");
        ResultSet resultset = pstm.executeQuery();
        while (resultset.next()) {
            list.add(new supplierDto(
                    resultset.getString("ID"),
                    resultset.getString("Name"),
                    resultset.getString("Address"),
                    resultset.getString("Contact")

            ));
        }
        return list;
    }

    public static boolean saveSupplier(supplierDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("INSERT INTO supplier (id,name,address,tel) VALUES (?,?,?,?)");
        pstm.setString(1, dto.getSupplierID());
        pstm.setString(2, dto.getSupplierName());
        pstm.setString(3, dto.getSupplierContactNumber());
        pstm.setString(4, dto.getSupplierAddress());
        return pstm.executeUpdate() > 0;
    }

    public static boolean updateSupplier(supplierDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("UPDATE supplier SET name=?, address=?, tel=? WHERE id = ?");
        pstm.setString(1, dto.getSupplierID());
        pstm.setString(2, dto.getSupplierName());
        pstm.setString(3, dto.getSupplierContactNumber());
        pstm.setString(4, dto.getSupplierAddress());
        return pstm.executeUpdate() > 0;
    }

    public static boolean deleteSupplier(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("DELETE supplier SET name=?, address=?, tel=? WHERE id = ?");
        pstm.setString(1, id);
        return pstm.executeUpdate() > 0;
    }

    public static supplierDto getSupplier(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM supplier WHERE id = ?");
        pstm.setString(1, id);
        ResultSet rs = pstm.executeQuery();
        if (rs.next()) {
            return new supplierDto(
                    rs.getString("ID"),
                    rs.getString("Name"),
                    rs.getString("Address"),
                    rs.getString("Contact")
            );
        }
        return null;
    }
}
