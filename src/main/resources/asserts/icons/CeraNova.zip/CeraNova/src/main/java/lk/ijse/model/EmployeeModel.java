package lk.ijse.model;

import lk.ijse.db.dbconnection;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.employeeDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeModel {
    public static List<employeeDto> getEmployees() throws SQLException, ClassNotFoundException {
        List<employeeDto> list = new ArrayList<>();
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM employee");
        ResultSet re = pstm.executeQuery();
        while (re.next()) {
            list.add(new employeeDto(
                    re.getString("ID"),
                    re.getString("Name"),
                    re.getString("Address"),
                    re.getString("Contact")

            ));
        }
        return list;
    }

    public static boolean saveEmployee(employeeDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("INSERT INTO employee (id,name,address,tel) VALUES (?,?,?,?)");
        pstm.setString(1, dto.getEmployeeID());
        pstm.setString(2, dto.getEmployeeName());
        pstm.setString(3, dto.getEmployeeContactNumber());
        pstm.setString(4, dto.getEmployeeAddress());
        return pstm.executeUpdate() > 0;
    }

    public static boolean updateEmployee(employeeDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("UPDATE employee SET name=?, address=?, tel=? WHERE id = ?");
        pstm.setString(1, dto.getEmployeeID());
        pstm.setString(2, dto.getEmployeeName());
        pstm.setString(3, dto.getEmployeeContactNumber());
        pstm.setString(4, dto.getEmployeeAddress());
        return pstm.executeUpdate() > 0;
    }

    public static boolean deleteEmployee(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("DELETE employee SET name=?, address=?, tel=? WHERE id = ?");
        pstm.setString(1, id);
        return pstm.executeUpdate() > 0;
    }

    public static employeeDto getEmployee(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM employee WHERE id = ?");
        pstm.setString(1, id);
        ResultSet res = pstm.executeQuery();
        if (res.next()) {
            return new employeeDto(
                    res.getString("ID"),
                    res.getString("Name"),
                    res.getString("Address"),
                    res.getString("Contact")
            );
        }
        return null;
    }

}
