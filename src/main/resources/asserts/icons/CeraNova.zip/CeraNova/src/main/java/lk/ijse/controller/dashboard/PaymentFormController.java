package lk.ijse.controller.dashboard;

import javafx.event.ActionEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class PaymentFormController {
    public TextField txtpaymentID;
    public TextField txtpaymentcost;
    public TextField txtpaymentmethod;
    public TextField txtpaymentdate;
    public TableView tablePayment;
    public TableColumn colpayID;
    public TableColumn colpaydate;
    public TableColumn cplpaymethod;
    public TableColumn colpaymentcost;
    public TableColumn colpaymenttime;
    public TableColumn colItemId;
    public TableColumn colorderID;
    public TableColumn colitemID;
    public TextField txtpaymenttime;
    public TextField txtorderID;
    public TextField txtcustomerID;
    public TextField txtitemId;




    public void buttonOnActionClear(ActionEvent actionEvent) {
    }

    public void buttonOnActionDelete(ActionEvent actionEvent) {
    }

    public void buttonOnActionUpdate(ActionEvent actionEvent) {
    }

    public void buttonOnActionSave(ActionEvent actionEvent) {
    }

    public void buttonOnActionBack(ActionEvent actionEvent) {
    }

}

