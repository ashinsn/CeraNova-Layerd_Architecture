package lk.ijse.model;

import lk.ijse.db.dbconnection;
import lk.ijse.db.dbconnection;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.itemDto;
import lk.ijse.dto.materialDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MaterialModel {
    public static List<materialDto> getMaterials() throws SQLException, ClassNotFoundException {
        List<materialDto> list = new ArrayList<>();
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM material");
        ResultSet resul = pstm.executeQuery();
        while (resul.next()) {
            list.add(new materialDto(
                    resul.getString("ID"),
                    resul.getString("Name"),
                    resul.getString("Type"),
                    resul.getString("Quantity")

            ));
        }
        return list;
    }

    public static boolean saveMaterial(materialDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("INSERT INTO material (id,name,type,quantity) VALUES (?,?,?,?)");
        pstm.setString(1, dto.getMaterialID());
        pstm.setString(2, dto.getMaterialName());
        pstm.setString(3, dto.getMaterialType());
        pstm.setString(4, dto.getMaterialQuantity());
        return pstm.executeUpdate() > 0;
    }

    public static boolean updateMaterial(materialDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("UPDATE material SET name=?, type=?, quantity=? WHERE id = ?");
        pstm.setString(1, dto.getMaterialID());
        pstm.setString(2, dto.getMaterialName());
        pstm.setString(3, dto.getMaterialType());
        pstm.setString(4, dto.getMaterialQuantity());
        return pstm.executeUpdate() > 0;
    }

    public static boolean deleteMaterial(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("DELETE material SET name=?, type=?, quantity=? WHERE id = ?");
        pstm.setString(1, id);
        return pstm.executeUpdate() > 0;
    }

    public static itemDto getMaterial(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM material WHERE id = ?");
        pstm.setString(1, id);
        ResultSet resul = pstm.executeQuery();
        if (resul.next()) {
            return new itemDto(
                    resul.getString("ID"),
                    resul.getString("Type"),
                    resul.getString("Size"),
                    resul.getString("QuantityOfItem")
            );
        }
        return null;
    }
}
