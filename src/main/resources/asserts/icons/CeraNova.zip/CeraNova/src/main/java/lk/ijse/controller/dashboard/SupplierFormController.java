package lk.ijse.controller.dashboard;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import lk.ijse.db.dbconnection;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.supplierDto;
import lk.ijse.dto.tm.customerTm;
import javafx.scene.control.Alert;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.scene.control.cell.PropertyValueFactory;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.SortEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import lk.ijse.dto.tm.supplierTm;
import lk.ijse.model.CustomerModel;
import lk.ijse.model.SupplierModel;

public class SupplierFormController implements Initializable {
    public TextField txtsupplierID;
    public TextField txtsuppliercontactnumber;
    public TextField txtsupplieraddress;
    public TextField txtsuppliername;
    public TableView tableSupplier;
    public TableColumn colsupplierID;
    public TableColumn colsuppliername;
    public TableColumn colsupplieraddress;
    public TableColumn colsuppliercontactnumber;
    public TableColumn colUserID;


    public void buttonOnActionClear(ActionEvent actionEvent) {

    }

    public void buttonOnActionDelete(ActionEvent actionEvent) {
    }

    public void buttonOnActionUpdate(ActionEvent actionEvent) {
    }

    public void buttonOnActionSave(ActionEvent actionEvent) {
        String id = txtsuppliername.getText();
        String name = txtsupplierID.getText();
        String address = txtsupplieraddress.getText();
        String contact = txtsuppliercontactnumber.getText();
        if (id.isEmpty() || name.isEmpty() || address.isEmpty() || contact.isEmpty()){
            new Alert(Alert.AlertType.ERROR,"Field Not found").showAndWait();
            return;
        }
        supplierDto dto = new supplierDto(
                id,
                name,
                address,
                contact
        );
        try {
            boolean isSaved = supplierDto.saveSupplier(dto);
            if (isSaved){
                new Alert(Alert.AlertType.INFORMATION,"Success").showAndWait();
                getAllSuppliers();
            }else {
                new Alert(Alert.AlertType.ERROR,"Fail").showAndWait();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }


    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        colsupplierID.setCellValueFactory(new PropertyValueFactory<>("ID"));
        colsuppliername.setCellValueFactory(new PropertyValueFactory<>("Name"));
        colsupplieraddress.setCellValueFactory(new PropertyValueFactory<>("Address"));
        colsuppliercontactnumber.setCellValueFactory(new PropertyValueFactory<>("Contact"));

        tableListener();
        try {

            getAllSuppliers();


        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
    public void tableListener(){}

    private void getAllSuppliers() throws SQLException, ClassNotFoundException {
        List<supplierDto> suppliers = SupplierModel.getSuppliers();
        List<supplierTm> tmList = new ArrayList<>();
        for(supplierDto dto: suppliers){
            tmList.add(new supplierTm(
                    dto.getSupplierID(),
                    dto.getSupplierName(),
                    dto.getSupplierAddress(),
                    dto.getSupplierContactNumber()
            ));
        }
        updateSupplierTable(tmList);
    }
    private void updateSupplierTable(List<supplierTm> list){

    }
}
