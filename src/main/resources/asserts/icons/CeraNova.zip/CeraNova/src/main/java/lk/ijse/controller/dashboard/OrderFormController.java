package lk.ijse.controller.dashboard;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.dto.orderDto;
import lk.ijse.dto.tm.orderTm;
import lk.ijse.model.OrderModel;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class OrderFormController implements Initializable {
    public TextField txtOrderID;
    public TextField txtDeliveryID;
    public TextField txtOrderdescription;
    public TextField txtOrderdate;
    public TableView tableOrder;
    public TableColumn colOrderID;
    public TableColumn colOrderdate;
    public TableColumn colOrderdescription;
    public TableColumn colDeliveryID;
    public AnchorPane root;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        colOrderID.setCellValueFactory(new PropertyValueFactory<>("ID"));
        colOrderdate.setCellValueFactory(new PropertyValueFactory<>("Name"));
        colOrderdescription.setCellValueFactory(new PropertyValueFactory<>("Address"));

        tableListener();
        try {

            getAllOrders();


        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
    public void tableCustomer(SortEvent<TableView> tableViewSortEvent) {
    }

    public void btnOnActionBack(ActionEvent actionEvent) {
    }

    public void btnOnActionDelete(ActionEvent actionEvent) {
    }

    public void btnOnActionClear(ActionEvent actionEvent) {
    }

    public void buttonOnActionUpdate(ActionEvent actionEvent) {
    }

    public void buttonOnActionSave(ActionEvent actionEvent) {
        String id = txtOrderID.getText();
        String date= txtOrderdate.getText();
        String description = txtOrderdescription.getText();
        String delivaryID = txtDeliveryID.getText();


        if (id.isEmpty() || date.isEmpty() || description.isEmpty() ){
            new Alert(Alert.AlertType.ERROR,"Field Not found").showAndWait();
            return;
        }

        orderDto dto = new orderDto(
                id,
                date,
                description,
                delivaryID
        );
        try {
            boolean isSaved = OrderModel.saveOrder(dto);
            if (isSaved){
                new Alert(Alert.AlertType.INFORMATION,"Success").showAndWait();
                getAllOrders();
            }else {
                new Alert(Alert.AlertType.ERROR,"Fail").showAndWait();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    private void getAllOrders() throws SQLException, ClassNotFoundException {
        List<orderDto> orders = OrderModel.getOrders();
        List<orderTm> tmList = new ArrayList<>();
        for(orderDto dto: orders){
            tmList.add(new orderTm(
                    dto.getOrderID(),
                    dto.getOrderDate(),
                    dto.getOrderDescription()
            ));
        }
        updateOrderTable(tmList);
    }

    private void updateOrderTable(List<orderTm> tmList) {
    }

    private void tableListener(){}

    public void buttonOnActionCustomerOrder(ActionEvent actionEvent) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/customerorder_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Customer-Order Management");
        stage.show();
    }

    public void buttonOnActionBack(ActionEvent actionEvent) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        //stage.setTitle("");
        stage.show();
    }
}
