package lk.ijse.controller.dashboard;

import javafx.event.ActionEvent;
import javafx.scene.control.SortEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class SupplierMaterialFormController {

    public TableColumn colsupplierID;
    public TableColumn colmaterialID;
    public TableColumn colstockDetails;

    public void supplierMaterialTable(SortEvent<TableView> tableViewSortEvent) {
    }

    public void btnOnActionClear(ActionEvent actionEvent) {
    }

    public void btnOnActionDelete(ActionEvent actionEvent) {
    }

    public void btnOnActionUpdate(ActionEvent actionEvent) {
    }

    public void btnOnActionSave(ActionEvent actionEvent) {
    }

    public void btnOnActionBack(ActionEvent actionEvent) {
    }
}
