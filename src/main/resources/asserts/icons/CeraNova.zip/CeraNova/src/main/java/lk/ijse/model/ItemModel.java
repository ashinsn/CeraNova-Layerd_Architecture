package lk.ijse.model;

import lk.ijse.db.dbconnection;
import lk.ijse.db.dbconnection;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.itemDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class ItemModel {
    public static List<itemDto> getItems() throws SQLException, ClassNotFoundException {
        List<itemDto> list = new ArrayList<>();
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM item");
        ResultSet resu = pstm.executeQuery();
        while (resu.next()) {
            list.add(new itemDto(
                    resu.getString("ID"),
                    resu.getString("Type"),
                    resu.getString("Size"),
                    resu.getString("QuantityOfItem")

            ));
        }
        return list;
    }

    public static boolean saveItem(itemDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("INSERT INTO item (id,type,size,quantityofitem) VALUES (?,?,?,?)");
        pstm.setString(1, dto.getItemID());
        pstm.setString(2, dto.getItemType());
        pstm.setString(3, dto.getItemSize());
        pstm.setString(4, dto.getQuantityOfItem());
        return pstm.executeUpdate() > 0;
    }

    public static boolean updateItem(itemDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("UPDATE item SET type=?, size=?, quantityofitem=? WHERE id = ?");
        pstm.setString(1, dto.getItemID());
        pstm.setString(2, dto.getItemType());
        pstm.setString(3, dto.getItemSize());
        pstm.setString(4, dto.getQuantityOfItem());
        return pstm.executeUpdate() > 0;
    }

    public static boolean deleteItem(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("DELETE item SET type=?, size=?, quantityofitem=? WHERE id = ?");
        pstm.setString(1, id);
        return pstm.executeUpdate() > 0;
    }

    public static itemDto getItems(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM item WHERE id = ?");
        pstm.setString(1, id);
        ResultSet resu = pstm.executeQuery();
        if (resu.next()) {
            return new itemDto(
                    resu.getString("ID"),
                    resu.getString("Type"),
                    resu.getString("Size"),
                    resu.getString("QuantityOfItem")
            );
        }
        return null;
    }

}


