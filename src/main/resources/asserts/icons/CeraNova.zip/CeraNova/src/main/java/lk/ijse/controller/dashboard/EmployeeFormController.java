package lk.ijse.controller.dashboard;

import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import lk.ijse.dto.employeeDto;
import lk.ijse.dto.tm.employeeTm;
import lk.ijse.model.EmployeeModel;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class EmployeeFormController  implements Initializable {
    public TextField txtemployeeID;
    public TextField txtsalaryId;
    public TextField txtemployeecontactnum;
    public TextField txtemployeeAddress;
    public TextField txtemployeeName;
    public TableView tableEmployee;
    public TableColumn colempID;
    public TableColumn colempName;
    public TableColumn colempAddress;
    public TableColumn colempContact;
    public TableColumn colsalaryId;

    public JFXButton test;
    public AnchorPane root;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        colempID.setCellValueFactory(new PropertyValueFactory<>("ID"));
        colempName.setCellValueFactory(new PropertyValueFactory<>("Name"));
        colempAddress.setCellValueFactory(new PropertyValueFactory<>("Address"));
        colempContact.setCellValueFactory(new PropertyValueFactory<>("Contact"));

        tableListener();
        try {

            getAllEmployees();


        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public void buttonOnActionClear(ActionEvent actionEvent) {

    }

    public void buttonOnActionSave(ActionEvent actionEvent) {
        String id = txtemployeeID.getText();
        String name = txtemployeeName.getText();
        String address = txtemployeeAddress.getText();
        String contact = txtemployeecontactnum.getText();
        if (id.isEmpty() || name.isEmpty() || address.isEmpty() || contact.isEmpty()){
            new Alert(Alert.AlertType.ERROR,"Field Not found").showAndWait();
            return;
        }
        employeeDto dto = new employeeDto(
                id,
                name,
                address,
                contact
        );
        try {
            boolean isSaved = EmployeeModel.saveEmployee(dto);
            if (isSaved){
                new Alert(Alert.AlertType.INFORMATION,"Success").showAndWait();
                getAllEmployees();
            }else {
                new Alert(Alert.AlertType.ERROR,"Fail").showAndWait();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }



    }

    public void buttonOnActionUpdate(ActionEvent actionEvent) {
    }

    public void buttonOnActionDelete(ActionEvent actionEvent) {
    }

    public void buttonOnActionBack(ActionEvent actionEvent) throws IOException {
            AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard_form.fxml"));
            Scene scene = new Scene(anchorPane);
            Stage stage = (Stage) root.getScene().getWindow();
            stage.setScene(scene);
            stage.centerOnScreen();
            //stage.setTitle("Payment Manage");
            stage.show();
    }
    private void getAllEmployees() throws SQLException, ClassNotFoundException {
        List<employeeDto> employees = EmployeeModel.getEmployees();
        List<employeeTm> tmList;
        tmList = new ArrayList<>();
        for(employeeDto dto: employees){
            tmList.add(new employeeTm(
                    dto.getEmployeeID(),
                    dto.getEmployeeName(),
                    dto.getEmployeeAddress(),
                    dto.getEmployeeContactNumber()
            ));
        }
        updateEmployeeTable(tmList);
    }
  /*  public void btnSalaryOnAction(ActionEvent actionEvent) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard/payment_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.setTitle("Salary Management");
        stage.show();
    }*/


    public void tableListener(){

    }
    private void updateEmployeeTable(List<employeeTm> list){
//        tableCustomer.setItems(FXCollections.observableArrayList(list));
//        tableCustomer.refresh();
    }

    public void btnSalaryOnAction(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/veiw/salary_form.fxml"));
        Stage stage = new Stage();
        stage.setScene(new javafx.scene .Scene(root));
        stage.setTitle("Salary Form");
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.initOwner(test.getScene().getWindow());



    }
}
