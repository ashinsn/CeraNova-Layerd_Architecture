package lk.ijse.model;

import lk.ijse.db.dbconnection;
import lk.ijse.db.dbconnection;
import lk.ijse.dto.customerDto;
import lk.ijse.dto.customerDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerModel {
    public static List<customerDto> getCustomers() throws SQLException, ClassNotFoundException {
        List<customerDto> list = new ArrayList<>();
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM customer");
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            list.add(new customerDto(
                    rs.getString("customerID"),
                    rs.getString("customerName"),
                    rs.getString("customerAddress"),
                    rs.getString("customerContactNumber")

            ));
        }
        return list;
    }

    public static boolean saveCustomer(customerDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("INSERT INTO customer (id,name,address,tel) VALUES (?,?,?,?)");
        pstm.setString(1, dto.getCustomerID());
        pstm.setString(2, dto.getCustomerName());
        pstm.setString(3, dto.getCustomerContactNumber());
        pstm.setString(4, dto.getCustomerAddress());
        return pstm.executeUpdate() > 0;
    }

    public static boolean updateCustomer(customerDto dto) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("UPDATE customer SET name=?, address=?, tel=? WHERE id = ?");
        pstm.setString(1, dto.getCustomerID());
        pstm.setString(2, dto.getCustomerName());
        pstm.setString(3, dto.getCustomerContactNumber());
        pstm.setString(4, dto.getCustomerAddress());
        return pstm.executeUpdate() > 0;
    }

    public static boolean deleteCustomer(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("DELETE customer SET name=?, address=?, tel=? WHERE id = ?");
        pstm.setString(1, id);
        return pstm.executeUpdate() > 0;
    }

    public static customerDto getCustomer(String id) throws SQLException, ClassNotFoundException {
        Connection con = dbconnection.getInstance().getConnection();
        PreparedStatement pstm = con.prepareStatement("SELECT * FROM customer WHERE id = ?");
        pstm.setString(1, id);
        ResultSet rs = pstm.executeQuery();
        if (rs.next()) {
            return new customerDto(
                    rs.getString("ID"),
                    rs.getString("Name"),
                    rs.getString("Address"),
                    rs.getString("Contact")
            );
        }
        return null;
    }

}

